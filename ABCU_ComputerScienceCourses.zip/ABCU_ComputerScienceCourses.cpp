//============================================================================
// Name        : ABCU_ComputerScience_Courses.cpp
// Author      : Paul Hatfield
// Version     : 1.2
// Copyright   : Copyright (c) 2017 SNHU COCE
// Description : Computer Science Courses in C++, Ansi-style
//============================================================================

#include <iostream>
#include <fstream>
#include <vector>

using namespace std;

// Definition of structure course
struct Course{
    string courseNumber;
    string name;
    vector<string> prerequisites;

};

// Function to split string into list of strings using a space as a delimiter 
vector<string> tokenize(string s, string del = " ")
{
    vector<string> stringArray;
    int start = 0;
    int end = s.find(del);
    while (end != -1) {
        stringArray.push_back(s.substr(start, end - start));
        start = end + del.size();
        end = s.find(del, start);
    }

stringArray.push_back(s.substr(start, end - start));


return stringArray;

}

// Function to load file and store the details into list of courses
vector<Course> LoadDataStructure()
{
    // Using the iftstream class as a method to open file
    ifstream fin("abcu.txt",ios::in);
    vector<Course> courses;
    string line;
    // Infinite loop
    while(1)
    {
        getline(fin,line);
        // When the end of file is reached then break the loop
        // a -1 as been used inside the text file to mark the EOF (End of File)
        if(line=="-1")
        break;
        Course course;
        // getting tokenized information which is separated by commas
        vector<string> tokenizedInformation=tokenize(line,",");
        // Storing information on the structure course
        course.courseNumber=tokenizedInformation[0];
        course.name =tokenizedInformation[1];
        
        // if there are prerequisites then storing them too
        for(int i=2;i<tokenizedInformation.size();i++)
        {
            course.prerequisites.push_back(tokenizedInformation[i]);
        }
        // append the current course into the list of courses
        courses.push_back(course);
    }


// closing the file for security & memory
fin.close();


// return the courses list
return courses;

}

// printing course information of selected course in given format
void printCourse(Course course)
{
    string courseNumber= course.courseNumber;
    string name=course.name;
    vector<string> prerequisites=course.prerequisites;
    cout<<"Course Number: "<<courseNumber<<endl;
    cout<<"Course Name: "<<name<<endl;
    cout<<"Prerequisites: ";
    
    for(int i=0;i<prerequisites.size();i++)
    {
        cout<<prerequisites[i]<<" ";
    }
    // Using 2 line breaks for visual appeal
    cout<<"\n\n";
}

// printing course information of all courses in given format
    void printCourseList(vector<Course> courses)
    {
        int n=courses.size();
        
        // Sorting the list
        for(int i=0;i<n-1;i++)
        {
            for(int j=0;j<n-i-1;j++)
            {
                // if courses index j.courseNumber is greater than courses index j+1
                // then swap courses J+1 with courses J
                if(courses[j].courseNumber > courses[j+1].courseNumber)
                {
                    swap(courses[j+1],courses[j]);
                }
            }

        }


    // Loop through list of courses to print courses information
        for(int i=0;i<n;i++)
        {
            printCourse(courses[i]);
        }


    }

// search the course by user entered course number
void searchCourse(vector<Course> courses)
{
    int n=courses.size();
    string courseNumber;
    // use the f variable for a method of error handling
    int f=0;
    cout<<"Enter courseNumber: ";
    cin>>courseNumber;
    
    for(int i=0;i<n;i++)
    {
        // if course found then print it
        if(courses[i].courseNumber==courseNumber)
        {
            // f=1 defines course found (error handling method)
            f=1;
            printCourse(courses[i]);
            break;
        }

    }


    // if no course found (defined by f==0) then print error message
    if(f==0)
    {
    cout<<"Course with given course number not found\n";
    }

}

int main(int argc, char **argv)
{
    vector<Course> courses;
    
    // Print user menu
    cout<<"Press [1] Load Data Structure\n";
    cout<<"Press [2] Print Course List\n";
    cout<<"Press [3] Print Course\n";
    cout<<"Press [4] Exit\n";
    int ch;
    
    // do while loop will run until user enters 4 to exit
    do{
        // Prompt user to enter their choice
        cout<<"\nEnter your choice: ";
        cin>>ch;
        // using switch to execute users choice
        switch(ch)
        {
            case 1: 
                courses=LoadDataStructure();
            break;
            
            case 2: 
                printCourseList(courses); 
            break;
            
            case 3: 
                searchCourse(courses); 
            break;
            
            case 4: 
                cout<<"Exiting...\n"; 
            break;
            
            default: 
                cout<<"Invalid Choice\nTry again\n";

        }


    }while(ch!=4);
    
    return 0;

}